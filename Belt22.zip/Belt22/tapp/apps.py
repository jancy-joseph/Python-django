from django.apps import AppConfig


class TappConfig(AppConfig):
    name = 'tapp'
