from django.shortcuts import render,redirect,HttpResponse
import datetime

# Create your views here.
def indexfunction(request):
    return render (request,"index.html")
def fruitspagefunction(request):
    context={
        "myimages":["apple.png","blackberry.png","raspberry.png","strawberry.png"]    
    }
    return render (request,"fruits.html",context)

def checkoutfunction(request):
    total_fruits = int(request.POST["strawberry"])+int(request.POST["raspberry"])+int(request.POST["apple"])
    context = {
        "strawberry_input": request.POST["strawberry"],
        "raspberry_input": request.POST["raspberry"],
        "apple_input": request.POST["apple"],
        "total":str(total_fruits),
        "time": datetime.datetime.now(),
        "first_name_input":request.POST["first_name"],
        "last_name_input":request.POST["last_name"],
        "student_id_input":request.POST["student_id"],
    }
    return render (request,"checkout.html",context)
