from django.urls import path,include
from . import views

urlpatterns = [
    path('', views.indexfunction),
#   path('',views.displayimages)
    path('fruits',views.fruitspagefunction),
    path('checkout',views.checkoutfunction)
]