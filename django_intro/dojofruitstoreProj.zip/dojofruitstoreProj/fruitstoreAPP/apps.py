from django.apps import AppConfig


class FruitstoreappConfig(AppConfig):
    name = 'fruitstoreAPP'
