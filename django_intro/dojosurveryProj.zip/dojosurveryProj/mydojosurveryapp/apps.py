from django.apps import AppConfig


class MydojosurveryappConfig(AppConfig):
    name = 'mydojosurveryapp'
