from django.apps import AppConfig


class SrtvshowappConfig(AppConfig):
    name = 'srtvshowApp'
