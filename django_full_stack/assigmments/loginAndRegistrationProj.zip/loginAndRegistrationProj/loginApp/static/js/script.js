// $(document).ready(function(){
//     // $('#Logoutid').click(function(){
//     //     console.log("flushing sessions from db");
//     //     request.session.flush();
//     // })
// })